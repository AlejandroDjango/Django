# encoding:utf-8
from py2neo import Relationship


class WithSalt(Relationship):
    pass


class OfPlayer(Relationship):
    pass


class WithScope(Relationship):
    pass


class WithDocument(Relationship):
    pass
